package com.mycompany.fireapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.firebase.client.Firebase;

public class MainActivity extends AppCompatActivity {

    private Button mbutton;
    private Firebase mref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Firebase.setAndroidContext(this);
        mref = new Firebase("https://fireapp-daa01.firebaseio.com/");



        mbutton = (Button) findViewById(R.id.addButton);

        mbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Firebase mrefChild = mref.child("Name");
                mrefChild.setValue("Chisty");
            }
        });
    }
}
